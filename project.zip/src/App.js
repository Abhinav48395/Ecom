import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes } from './RoutingModule/Routes';


function App() {
  return (
    <div className="App">
     <Routes></Routes>
    </div>
  );
}

export default App;




//https://coolors.co/000000-14213d-fca311-e5e5e5-ffffff
