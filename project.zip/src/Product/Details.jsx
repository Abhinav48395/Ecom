import React from 'react'
import productData from './product.json';
import { Button } from 'react-bootstrap'
import './product.css'


export const Details = ({ match }) => {


    const productDetails = productData.Product.find((data) => data.p_name === match.params.pname);
    console.log("subCat", productDetails);


    const prodDetails = productDetails.subCatagory.find((data) => data.s_id === match.params.id)
    console.log("productdetails", prodDetails)
    return (
        <div>
            <br />
            <br />
            <br />
            <div className="container">
                <div className="row">
                    <div className="col-lg-6">
                        <img src={prodDetails.image} width="400" height="400px" />
                        <br></br>

                    </div>
                    <div className="col-lg-6">
                        <div className="details">
                            <h1>{prodDetails.company}</h1>

                            <h5 style={{ color: 'green' }}>	₹ {prodDetails.price}</h5><br />
                            <h3>About This Item :</h3>
                            <p>{prodDetails.s_des}</p>
                            <Button variant="warning">Add to cart</Button>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    )
}
