import React from 'react'
import { Header } from '../Layout/Header'
import { Header2 } from '../Layout/Header2'

import { Route, Switch, BrowserRouter as Router } from 'react-router-dom'
import { Login } from '../auth/Login'
import { Home } from '../component/Home'
import { Contact } from '../component/Contact'
import { Sign } from '../auth/Sign'
import { ProductCatagory } from '../Product/ProductCatagory'
import { ProductSub } from '../Product/ProductSub'
import { Details } from '../Product/Details'
import { Footer } from '../Layout/Footer'
import { Cart } from '../component/Cart'
import { CartProvider } from 'react-use-cart'


export const Routes = () => {
    return (
        <Router>
            <Header />
            <Header2/>
            <CartProvider>
            <Switch>


                <Route exact path="/" component={Home}></Route>
                <Route exact path="/login" component={Login}></Route>
                <Route exact path="/sign" component={Sign}></Route>
                <Route exact path="/contact" component={Contact}></Route>

                <Route path="/productcategory" component={ProductCatagory}></Route>
                <Route path="/psubcat/:pname" component={ProductSub}></Route>
                <Route path="/productdetails/:pname/:id" component={Details}></Route>
                <Route exact path="/cart" component={Cart}></Route>
            </Switch>
            </CartProvider>
            <Footer></Footer>
        </Router>
    )
}
