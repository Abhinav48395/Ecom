import React from 'react'
import '../App.css'


export const Footer = () => {
    return (
        <><br /><br /><br /><br /><br /><br /><br /><br />


            <div className="container-fluid footcol2"><br /><br />
                <div className="container">
                    <div className="row">
                        <div className="col align">
                            <h5>JOYCART: The One-stop Shopping Destination</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus aperiam et veniam nemo sint quo obcaecati molestias, consectetur atque, numquam, praesentium libero dignissimos. Facere cupiditate, velit repudiandae porro architecto quae harum, a exercitationem quam magni quibusdam pariatur vero laudantium perferendis maxime natus tempore similique rem laborum nesciunt est. Saepe, in.</p>
                            <h5>No Cost EMI</h5>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Accusamus non nam modi quidem sequi placeat quia dolores error sapiente architecto?</p>
                            <h5>EMI on Debit Cards
                            </h5>
                            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Consequuntur, incidunt pariatur optio voluptatibus amet rem fuga facere esse vero atque quam autem soluta eligendi iusto, hic sapiente! Deleniti, provident nobis.</p>
                            <h5>Mobile Exchange Offers</h5>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Officiis, incidunt.</p>
                            <h5>What Can You Buy From Flipkart?
                            </h5><br />
                            <h5>Mobile Phones</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>Laptop</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>Tablet</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>Gaming</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>TV</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>Air Conditioners</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>Washing Machine</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                           <h5>Refrigerator</h5>
                           <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Necessitatibus at odio beatae illo quibusdam eaque nesciunt mollitia, earum esse asperiores adipisci rerum suscipit aliquam maxime tempore sequi provident facere inventore!</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-fluid footcol" ><br />
                <div className="container">

                    <div className="row">
                        <div className="col">
                            <p>ABOUT</p>
                            <p>Contact Us</p>
                            <p>About Us</p>
                            <p>Careers</p>
                            <p>JoyCart Stories</p>
                            <p>Press</p>
                        </div>
                        <div className="col">
                            <p>HELP
                            </p>
                            <p>Payments</p>
                            <p>Shipping</p>
                            <p>Cancellation</p>
                            <p>FAQ</p>
                            <p>Report</p>
                        </div>
                        <div className="col">
                            <p>POLICY</p>
                            <p>Return Policy</p>
                            <p>Terms of Use</p>
                            <p>Security</p>
                            <p>Privacy</p>
                            <p>Sitemap</p>
                        </div>
                        <div className="col">
                            <p>SOCIAL</p>
                            <p>Facebook</p>
                            <p>Twitter</p>
                            <p>Youtube</p>

                        </div>
                        <div className="col">
                            <p>Mail Us:</p>
                            <address>Flipkart Internet Private Limited,

                                Buildings Alyssa, Begonia &

                                Clove Embassy Tech Village,

                                Outer Ring Road, Devarabeesanahalli Village,

                                Bengaluru, 560103,

                                Karnataka, India</address>
                        </div>
                        <div className="col">
                            <p>Registered Office Address:</p>
                            <address>Flipkart Internet Private Limited,

                                Buildings Alyssa, Begonia &

                                Clove Embassy Tech Village,

                                Outer Ring Road, Devarabeesanahalli Village,

                                Bengaluru, 560103,

                                Karnataka, India

                                CIN : U51109KA2012PTC066107

                                Telephone: 1800 202 9898</address>
                        </div>
                    </div><br /><br />
                    <hr width="100%" color="white" />
                    <div className="row">
                        <div className="col">
                            <h6>Sell On Flipkart</h6>
                        </div>

                        <div className="col"> <h6>Advertise</h6></div>
                        <div className="col"> <h6>Gift Cards</h6></div>
                        <div className="col"> <h6>Help Center</h6></div>
                        <div className="col"> <h6>© 2007-2021 Flipkart.com</h6></div>

                    </div>
                </div>
            </div>
        </>
    )
}
