import React from 'react'
import { Navbar, Container, Nav } from 'react-bootstrap'
import {Link} from 'react-router-dom'
import '../App.css'
import cart from './cart.png'

export const Header = () => {
    return (
        <>
        
            <Navbar  className="bar sticky-top" variant="dark">
                <Container>
                    <Navbar.Brand as={Link} to="/" className="brand">JOYCART</Navbar.Brand>
                    <Nav className="me-auto">
                       
                        <Nav.Link className="element" as={Link} to="/sign">Sign Up</Nav.Link>
                        <Nav.Link className="element" as={Link} to="/login">login</Nav.Link>
                        <Nav.Link className="element" as={Link} to="/contact">Contact</Nav.Link>
                      
                        <Nav.Link  as={Link} to="/cart">
                        <div className="cartcol">
                            <span style={{color:'black'}}>19</span>
                            <img src={cart} height="25px" width="25px" alt="" />
                           
                            </div>
                        </Nav.Link>
                      
                    </Nav>
                </Container>
            </Navbar>
      
    </>
    )
}
