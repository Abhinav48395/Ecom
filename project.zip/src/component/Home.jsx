import React from 'react'
import { Carousel, Card, Button } from 'react-bootstrap'
import car from './carousal.jpg'
import car1 from './play.webp'
import car2 from './phone.jfif'
import { Link } from 'react-router-dom'


export const Home = () => {
    return (
        <>



            {/* <div className="container-fluid"> */}
              
                    <Carousel>
                        <Carousel.Item>
                            <img
                                className="d-block w-100"
                                src={car}
                                alt="First slide"
                                height="540px"
                                width="1000px"
                            />
                            <Carousel.Caption>
                                <h3>30% Discount on Laptop</h3>
                                <p>Grab your deals</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                        <Carousel.Item>
                            <img
                                className="d-block w-100"
                                src={car1}
                                alt="Second slide"
                                height="540px"
                                width="1000px"
                            />

                            <Carousel.Caption>
                                <h3>20% Discount on gaming</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                        <Carousel.Item>
                            <img
                                className="d-block w-100"
                                src={car2}
                                alt="Third slide"
                                height="540px"
                                width="1000px"
                            />

                            <Carousel.Caption>
                                <h3>Third slide label</h3>
                                <p>Praesent commodo cursus magna, vel scelerisque nisl consectetur.</p>
                            </Carousel.Caption>
                        </Carousel.Item>
                    </Carousel>
                
            {/* </div> */}
            
          <div className="container">
              <div className="row">
                  <div className="col">
                      <h1>MAC</h1>
                      <Link as={Link} to="/productcategory">PRODUCTS</Link>
                  </div>
              </div>
          </div>
           

            


        </>
    )
}
